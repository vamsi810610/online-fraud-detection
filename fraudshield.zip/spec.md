# Online Payments Fraud Detection

## Current State
New project. No existing code.

## Requested Changes (Diff)

### Add
- Dashboard with real-time transaction monitoring feed
- Transaction submission form (simulate incoming payments with amount, location, device type, user ID)
- ML-based fraud scoring engine (rule-based heuristics on backend: amount thresholds, velocity checks, device anomalies, unusual hours)
- Fraud alert panel listing flagged transactions with risk scores and reasons
- Account risk profiler: per-user behavior tracking (login times, spending patterns, failed attempts)
- Fraud statistics overview (total transactions, flagged count, fraud rate, blocked accounts)
- Transaction history table with status (clean / suspicious / blocked)
- Adaptive learning: feedback loop where admins can mark transactions as confirmed fraud or false positive, adjusting future scoring weights

### Modify
N/A

### Remove
N/A

## Implementation Plan
1. Backend:
   - Store transactions with fields: id, userId, amount, location, deviceType, timestamp, riskScore, status (clean/suspicious/blocked), fraudReasons
   - Store user profiles: userId, totalTransactions, flaggedCount, lastLoginTime, failedLoginAttempts, avgSpend, blocked
   - Store fraud model weights: amount weight, velocity weight, device weight, time-of-day weight
   - Functions: submitTransaction (runs fraud scoring, saves result), getTransactions, getUserProfile, updateUserProfile, flagTransaction, markFraudFeedback (adjust weights), getStats, blockUser, getModelWeights
   - Fraud scoring logic: rule-based heuristics combining amount anomaly, transaction velocity, unusual device, odd hours, account history

2. Frontend:
   - Dashboard page: stats cards, live transaction feed, fraud alerts
   - Submit Transaction modal/form (simulate real-time payments)
   - Transaction history table with filters (all / suspicious / blocked)
   - User Profiles page with risk indicators
   - Model Settings page showing current weights and feedback outcomes
   - Responsive, dark-themed UI with risk color coding (green/yellow/red)

## UX Notes
- Use color-coded risk levels: green = clean, amber = suspicious, red = blocked/fraud
- Show fraud reasons as tags/badges on each transaction
- Dashboard should feel like a real-time security operations center (SOC)
- Stats should update immediately after each simulated transaction
- Provide a "Run Simulation" button that auto-generates a batch of test transactions
