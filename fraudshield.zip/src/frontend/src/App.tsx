import { useState, useEffect, useCallback } from "react";
import { Toaster, toast } from "sonner";
import Dashboard from "./components/Dashboard";
import FraudAlerts from "./components/FraudAlerts";
import UserProfiles from "./components/UserProfiles";
import ModelSettings from "./components/ModelSettings";
import Sidebar from "./components/Sidebar";
import { TransactionStatus, DeviceType, FeedbackType } from "./backend.d";
import type { backendInterface } from "./backend";
import { createActorWithConfig } from "./config";

export type View = "dashboard" | "alerts" | "profiles" | "model";

export interface FeedbackEntry {
  txId: string;
  feedback: FeedbackType;
  timestamp: Date;
}

let actorInstance: backendInterface | null = null;

async function getActor(): Promise<backendInterface> {
  if (!actorInstance) {
    actorInstance = await createActorWithConfig();
  }
  return actorInstance;
}

export default function App() {
  const [activeView, setActiveView] = useState<View>("dashboard");
  const [transactions, setTransactions] = useState<import("./backend.d").Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [feedbackLog, setFeedbackLog] = useState<FeedbackEntry[]>([]);

  const fetchTransactions = useCallback(async () => {
    try {
      const actor = await getActor();
      const txs = await actor.getAllTransactions();
      setTransactions(txs);
    } catch (err) {
      console.error("Failed to fetch transactions:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchTransactions();
    const interval = setInterval(() => void fetchTransactions(), 10000);
    return () => clearInterval(interval);
  }, [fetchTransactions]);

  const handleSubmitFeedback = async (txId: bigint, feedback: FeedbackType) => {
    try {
      const actor = await getActor();
      await actor.submitFeedback(txId, feedback);
      setFeedbackLog((prev) => [
        {
          txId: txId.toString(),
          feedback,
          timestamp: new Date(),
        },
        ...prev,
      ]);
      toast.success(
        feedback === FeedbackType.confirmedFraud
          ? "Marked as confirmed fraud"
          : "Marked as false positive"
      );
      await fetchTransactions();
    } catch {
      toast.error("Failed to submit feedback");
    }
  };

  const handleOverrideStatus = async (txId: bigint, newStatus: TransactionStatus) => {
    try {
      const actor = await getActor();
      await actor.adminOverrideTransaction(txId, newStatus);
      toast.success(`Transaction status updated to ${newStatus}`);
      await fetchTransactions();
    } catch {
      toast.error("Failed to override transaction status");
    }
  };

  const handleBlockUser = async (userId: string) => {
    try {
      const actor = await getActor();
      await actor.blockUser(userId);
      toast.success(`User ${userId} has been blocked`);
      await fetchTransactions();
    } catch {
      toast.error("Failed to block user");
    }
  };

  const handleUnblockUser = async (userId: string) => {
    try {
      const actor = await getActor();
      await actor.unblockUser(userId);
      toast.success(`User ${userId} has been unblocked`);
    } catch {
      toast.error("Failed to unblock user");
    }
  };

  const handleSubmitTransaction = async (
    userId: string,
    amount: number,
    location: string,
    deviceType: DeviceType
  ) => {
    try {
      const actor = await getActor();
      const id = await actor.submitTransaction(userId, amount, location, deviceType);
      toast.success(`Transaction #${id.toString()} submitted`);
      await fetchTransactions();
      return id;
    } catch {
      toast.error("Failed to submit transaction");
      throw new Error("Failed to submit transaction");
    }
  };

  const handleRunSimulation = async () => {
    const simData = [
      { userId: "user_alice", amount: 42.5, location: "New York, US", device: DeviceType.desktop },
      { userId: "user_bob", amount: 9750, location: "Unknown", device: DeviceType.mobile },
      { userId: "user_carol", amount: 185.0, location: "London, UK", device: DeviceType.desktop },
      { userId: "user_dave", amount: 6200, location: "Unknown", device: DeviceType.mobile },
      { userId: "user_eve", amount: 330.0, location: "Berlin, DE", device: DeviceType.tablet },
      { userId: "user_frank", amount: 11500, location: "Unknown", device: DeviceType.mobile },
      { userId: "user_grace", amount: 75.0, location: "Tokyo, JP", device: DeviceType.desktop },
      { userId: "user_heidi", amount: 8900, location: "Unknown", device: DeviceType.mobile },
    ];

    toast.info("Running simulation with 8 transactions...");
    try {
      const actor = await getActor();
      await Promise.all(
        simData.map((tx) =>
          actor.submitTransaction(tx.userId, tx.amount, tx.location, tx.device)
        )
      );
      toast.success("Simulation complete! 8 transactions submitted.");
      await fetchTransactions();
    } catch {
      toast.error("Simulation encountered errors");
    }
  };

  return (
    <div className="flex h-screen bg-soc-navy overflow-hidden font-sans">
      {/* Background grid */}
      <div className="fixed inset-0 grid-bg opacity-40 pointer-events-none" />
      <div className="fixed inset-0 scanlines pointer-events-none" />

      <Sidebar activeView={activeView} onNavigate={setActiveView} />

      <main className="flex-1 overflow-auto relative z-10">
        {activeView === "dashboard" && (
          <Dashboard
            transactions={transactions}
            isLoading={isLoading}
            onSubmitFeedback={handleSubmitFeedback}
            onOverrideStatus={handleOverrideStatus}
            onSubmitTransaction={handleSubmitTransaction}
            onRunSimulation={handleRunSimulation}
            onRefresh={fetchTransactions}
          />
        )}
        {activeView === "alerts" && (
          <FraudAlerts
            transactions={transactions}
            isLoading={isLoading}
            onOverrideStatus={handleOverrideStatus}
            onBlockUser={handleBlockUser}
            onRefresh={fetchTransactions}
          />
        )}
        {activeView === "profiles" && (
          <UserProfiles
            onBlockUser={handleBlockUser}
            onUnblockUser={handleUnblockUser}
          />
        )}
        {activeView === "model" && (
          <ModelSettings feedbackLog={feedbackLog} />
        )}
      </main>

      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "oklch(0.155 0.022 245)",
            border: "1px solid oklch(0.28 0.03 248)",
            color: "oklch(0.92 0.008 230)",
            fontFamily: "'Space Grotesk', sans-serif",
          },
        }}
      />
    </div>
  );
}
