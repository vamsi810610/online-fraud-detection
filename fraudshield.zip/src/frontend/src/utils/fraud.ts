import { Transaction, DeviceType, TransactionStatus } from "../backend.d";

export type FraudTag = "High Amount" | "Odd Hours" | "Unusual Device" | "High Velocity" | "Account History" | "Unknown Location";

export function getFraudTags(tx: Transaction): FraudTag[] {
  const tags: FraudTag[] = [];
  if (tx.amount > 5000) tags.push("High Amount");
  if (tx.location === "Unknown" || tx.location.toLowerCase().includes("unknown")) tags.push("Unknown Location");
  if (tx.deviceType === DeviceType.mobile && tx.riskScore > 0.6) tags.push("Unusual Device");
  if (tx.riskScore > 0.75) tags.push("High Velocity");
  if (tx.riskScore > 0.5) tags.push("Account History");

  // Odd hours: check if timestamp is between midnight and 5am
  const date = new Date(Number(tx.timestamp) / 1_000_000);
  const hour = date.getHours();
  if (hour >= 0 && hour < 5) tags.push("Odd Hours");

  return tags;
}

export function getRiskColor(riskScore: number): string {
  if (riskScore < 0.3) return "text-soc-green";
  if (riskScore < 0.6) return "text-soc-amber";
  return "text-soc-red";
}

export function getRiskBgColor(riskScore: number): string {
  if (riskScore < 0.3) return "bg-emerald-950/80 text-emerald-400 border-emerald-700/40";
  if (riskScore < 0.6) return "bg-amber-950/80 text-amber-400 border-amber-700/40";
  return "bg-red-950/80 text-red-400 border-red-700/40";
}

export function getStatusStyle(status: TransactionStatus): string {
  switch (status) {
    case TransactionStatus.clean: return "bg-emerald-950/80 text-emerald-400 border border-emerald-700/40";
    case TransactionStatus.suspicious: return "bg-amber-950/80 text-amber-400 border border-amber-700/40";
    case TransactionStatus.blocked: return "bg-red-950/80 text-red-400 border border-red-700/40";
  }
}

export function getStatusLabel(status: TransactionStatus): string {
  switch (status) {
    case TransactionStatus.clean: return "Clean";
    case TransactionStatus.suspicious: return "Suspicious";
    case TransactionStatus.blocked: return "Blocked";
  }
}

export function formatTimestamp(timestamp: bigint): string {
  const ms = Number(timestamp) / 1_000_000;
  const date = new Date(ms);
  return date.toLocaleTimeString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function formatDate(timestamp: bigint): string {
  const ms = Number(timestamp) / 1_000_000;
  const date = new Date(ms);
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function tagColorClass(tag: FraudTag): string {
  switch (tag) {
    case "High Amount": return "bg-red-950/60 text-red-400 border-red-700/40";
    case "Unknown Location": return "bg-orange-950/60 text-orange-400 border-orange-700/40";
    case "Unusual Device": return "bg-purple-950/60 text-purple-400 border-purple-700/40";
    case "High Velocity": return "bg-amber-950/60 text-amber-400 border-amber-700/40";
    case "Account History": return "bg-blue-950/60 text-blue-400 border-blue-700/40";
    case "Odd Hours": return "bg-slate-800/60 text-slate-400 border-slate-600/40";
    default: return "bg-muted text-muted-foreground border-border";
  }
}
