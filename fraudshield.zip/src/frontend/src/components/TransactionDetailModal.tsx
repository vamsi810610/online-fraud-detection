import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Transaction, TransactionStatus, FeedbackType } from "../backend.d";
import {
  getStatusStyle,
  getStatusLabel,
  getRiskColor,
  getFraudTags,
  tagColorClass,
  formatDate,
} from "../utils/fraud";
import { Monitor, Smartphone, Tablet, ThumbsUp, ThumbsDown, MapPin, Hash, User } from "lucide-react";
import { useState } from "react";

interface TransactionDetailModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  onOverrideStatus: (txId: bigint, newStatus: TransactionStatus) => Promise<void>;
  onSubmitFeedback: (txId: bigint, feedback: FeedbackType) => Promise<void>;
}

const DeviceIcon = ({ device }: { device: string }) => {
  if (device === "mobile") return <Smartphone className="w-4 h-4" />;
  if (device === "tablet") return <Tablet className="w-4 h-4" />;
  return <Monitor className="w-4 h-4" />;
};

export default function TransactionDetailModal({
  transaction,
  onClose,
  onOverrideStatus,
  onSubmitFeedback,
}: TransactionDetailModalProps) {
  const [overrideStatus, setOverrideStatus] = useState<TransactionStatus | "">("");
  const [isOverriding, setIsOverriding] = useState(false);

  if (!transaction) return null;

  const tags = getFraudTags(transaction);

  const handleOverride = async () => {
    if (!overrideStatus) return;
    setIsOverriding(true);
    try {
      await onOverrideStatus(transaction.id, overrideStatus as TransactionStatus);
      onClose();
    } finally {
      setIsOverriding(false);
    }
  };

  return (
    <Dialog open={!!transaction} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-soc-panel border-soc-border text-foreground max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-foreground font-display">
            Transaction Details
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* ID & Status */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Hash className="w-4 h-4 text-soc-muted" />
              <span className="font-mono text-soc-cyan text-sm">TX#{transaction.id.toString()}</span>
            </div>
            <span className={`text-xs px-2.5 py-1 rounded-full font-mono uppercase font-semibold ${getStatusStyle(transaction.status)}`}>
              {getStatusLabel(transaction.status)}
            </span>
          </div>

          {/* Fields grid */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-secondary/50 rounded-md p-3">
              <p className="text-soc-muted text-xs mb-1 flex items-center gap-1">
                <User className="w-3 h-3" /> User ID
              </p>
              <p className="font-mono text-foreground truncate">{transaction.userId}</p>
            </div>
            <div className="bg-secondary/50 rounded-md p-3">
              <p className="text-soc-muted text-xs mb-1">Amount</p>
              <p className="font-mono text-foreground font-semibold">
                ${transaction.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="bg-secondary/50 rounded-md p-3">
              <p className="text-soc-muted text-xs mb-1 flex items-center gap-1">
                <MapPin className="w-3 h-3" /> Location
              </p>
              <p className="font-mono text-foreground text-xs">{transaction.location}</p>
            </div>
            <div className="bg-secondary/50 rounded-md p-3">
              <p className="text-soc-muted text-xs mb-1">Device</p>
              <p className="font-mono text-foreground flex items-center gap-1">
                <DeviceIcon device={transaction.deviceType} />
                <span className="capitalize text-xs">{transaction.deviceType}</span>
              </p>
            </div>
            <div className="bg-secondary/50 rounded-md p-3">
              <p className="text-soc-muted text-xs mb-1">Risk Score</p>
              <p className={`font-mono font-bold ${getRiskColor(transaction.riskScore)}`}>
                {(transaction.riskScore * 100).toFixed(1)}%
              </p>
            </div>
            <div className="bg-secondary/50 rounded-md p-3">
              <p className="text-soc-muted text-xs mb-1">Timestamp</p>
              <p className="font-mono text-foreground text-xs">{formatDate(transaction.timestamp)}</p>
            </div>
          </div>

          {/* Fraud tags */}
          {tags.length > 0 && (
            <div>
              <p className="text-xs text-soc-muted mb-2 font-mono uppercase tracking-wider">Fraud Indicators</p>
              <div className="flex flex-wrap gap-1.5">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className={`text-xs font-mono border ${tagColorClass(tag)}`}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Feedback actions */}
          <div className="border-t border-soc-border pt-4">
            <p className="text-xs text-soc-muted mb-3 font-mono uppercase tracking-wider">Feedback</p>
            <div className="flex gap-2">
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="flex-1 border-emerald-700/50 text-emerald-400 hover:bg-emerald-950/50"
                onClick={() => onSubmitFeedback(transaction.id, FeedbackType.falsePositive)}
              >
                <ThumbsUp className="w-3.5 h-3.5 mr-1.5" />
                False Positive
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="flex-1 border-red-700/50 text-red-400 hover:bg-red-950/50"
                onClick={() => onSubmitFeedback(transaction.id, FeedbackType.confirmedFraud)}
              >
                <ThumbsDown className="w-3.5 h-3.5 mr-1.5" />
                Confirm Fraud
              </Button>
            </div>
          </div>

          {/* Admin override */}
          <div className="border-t border-soc-border pt-4">
            <p className="text-xs text-soc-muted mb-3 font-mono uppercase tracking-wider">Admin Override</p>
            <div className="flex gap-2">
              <Select value={overrideStatus} onValueChange={(v) => setOverrideStatus(v as TransactionStatus)}>
                <SelectTrigger className="flex-1 bg-secondary border-soc-border text-foreground text-sm">
                  <SelectValue placeholder="Select new status..." />
                </SelectTrigger>
                <SelectContent className="bg-popover border-soc-border">
                  <SelectItem value={TransactionStatus.clean} className="text-foreground">Clean</SelectItem>
                  <SelectItem value={TransactionStatus.suspicious} className="text-foreground">Suspicious</SelectItem>
                  <SelectItem value={TransactionStatus.blocked} className="text-foreground">Blocked</SelectItem>
                </SelectContent>
              </Select>
              <Button
                type="button"
                size="sm"
                disabled={!overrideStatus || isOverriding}
                onClick={handleOverride}
                className="bg-soc-cyan text-soc-navy font-semibold hover:bg-soc-cyan/90"
              >
                {isOverriding ? "Saving..." : "Override"}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
