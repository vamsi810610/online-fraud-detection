import { useState, useMemo } from "react";
import { Transaction, TransactionStatus, DeviceType } from "../backend.d";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import TransactionDetailModal from "./TransactionDetailModal";
import { FeedbackType } from "../backend.d";
import { createActorWithConfig } from "../config";
import {
  getStatusStyle,
  getStatusLabel,
  getRiskColor,
  getFraudTags,
  tagColorClass,
  formatDate,
} from "../utils/fraud";
import { AlertTriangle, Monitor, Smartphone, Tablet, UserX } from "lucide-react";

type FilterTab = "all" | "suspicious" | "blocked";

interface FraudAlertsProps {
  transactions: Transaction[];
  isLoading: boolean;
  onOverrideStatus: (txId: bigint, newStatus: TransactionStatus) => Promise<void>;
  onBlockUser: (userId: string) => Promise<void>;
  onRefresh: () => Promise<void>;
}

const DeviceIcon = ({ device }: { device: string }) => {
  const cls = "w-3.5 h-3.5";
  if (device === "mobile") return <Smartphone className={cls} />;
  if (device === "tablet") return <Tablet className={cls} />;
  return <Monitor className={cls} />;
};

export default function FraudAlerts({
  transactions,
  isLoading,
  onOverrideStatus,
  onBlockUser,
}: FraudAlertsProps) {
  const [activeTab, setActiveTab] = useState<FilterTab>("all");
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [overridingId, setOverridingId] = useState<string | null>(null);
  const [blockingId, setBlockingId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const sorted = [...transactions].sort((a, b) => Number(b.timestamp) - Number(a.timestamp));
    if (activeTab === "all") return sorted.filter((t) => t.status !== TransactionStatus.clean);
    if (activeTab === "suspicious") return sorted.filter((t) => t.status === TransactionStatus.suspicious);
    if (activeTab === "blocked") return sorted.filter((t) => t.status === TransactionStatus.blocked);
    return sorted;
  }, [transactions, activeTab]);

  const counts = useMemo(() => ({
    suspicious: transactions.filter((t) => t.status === TransactionStatus.suspicious).length,
    blocked: transactions.filter((t) => t.status === TransactionStatus.blocked).length,
    all: transactions.filter((t) => t.status !== TransactionStatus.clean).length,
  }), [transactions]);

  const handleOverride = async (tx: Transaction, newStatus: TransactionStatus) => {
    setOverridingId(tx.id.toString());
    try {
      await onOverrideStatus(tx.id, newStatus);
    } finally {
      setOverridingId(null);
    }
  };

  const handleBlock = async (userId: string) => {
    setBlockingId(userId);
    try {
      await onBlockUser(userId);
    } finally {
      setBlockingId(null);
    }
  };

  const tabs: { id: FilterTab; label: string; count: number }[] = [
    { id: "all", label: "All Alerts", count: counts.all },
    { id: "suspicious", label: "Suspicious", count: counts.suspicious },
    { id: "blocked", label: "Blocked", count: counts.blocked },
  ];

  return (
    <div className="p-6 space-y-5 min-h-full">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground font-display flex items-center gap-2">
          <AlertTriangle className="w-6 h-6 text-amber-400" />
          Fraud Alerts
        </h2>
        <p className="text-sm text-muted-foreground mt-1 font-mono">
          Flagged transactions requiring review
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1 bg-secondary/50 p-1 rounded-lg w-fit border border-soc-border">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`
              flex items-center gap-2 px-4 py-1.5 rounded-md text-sm font-medium transition-all duration-150
              ${activeTab === tab.id
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
              }
            `}
          >
            {tab.label}
            <span className={`
              text-[10px] font-mono px-1.5 py-0.5 rounded-full
              ${activeTab === tab.id ? "bg-soc-cyan/20 text-soc-cyan" : "bg-muted text-muted-foreground"}
            `}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Alerts Table */}
      <div className="bg-card border border-soc-border rounded-lg overflow-hidden">
        {/* Table header */}
        <div className="grid grid-cols-[70px_110px_85px_110px_40px_90px_90px_130px_150px] gap-2 px-4 py-2.5 border-b border-soc-border bg-secondary/30">
          {["ID", "User", "Amount", "Location", "Dev", "Risk", "Status", "Time", "Actions"].map((h) => (
            <span key={h} className="text-[10px] font-mono uppercase tracking-widest text-soc-muted">
              {h}
            </span>
          ))}
        </div>

        <ScrollArea className="h-[calc(100vh-310px)]">
          {isLoading ? (
            <div className="space-y-0">
              {["s1","s2","s3","s4","s5"].map((sk) => (
                <div key={sk} className="grid grid-cols-[70px_110px_85px_110px_40px_90px_90px_130px_150px] gap-2 px-4 py-3 border-b border-soc-border/30">
                  {["a","b","c","d","e","f","g","h","i"].map((s) => (
                    <Skeleton key={s} className="h-3 bg-secondary animate-shimmer" />
                  ))}
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
              <AlertTriangle className="w-8 h-8 mb-3 opacity-30" />
              <p className="text-sm font-mono">No alerts found</p>
            </div>
          ) : (
            filtered.map((tx) => {
              const tags = getFraudTags(tx);
              return (
                <div
                  key={tx.id.toString()}
                  className="grid grid-cols-[70px_110px_85px_110px_40px_90px_90px_130px_150px] gap-2 px-4 py-3 border-b border-soc-border/30 hover:bg-secondary/30 transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => setSelectedTx(tx)}
                    className="font-mono text-soc-cyan text-xs truncate text-left hover:underline"
                  >
                    #{tx.id.toString()}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedTx(tx)}
                    className="font-mono text-xs text-foreground truncate text-left"
                  >
                    {tx.userId}
                  </button>
                  <span className="font-mono text-xs text-foreground text-right">
                    ${tx.amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className="text-xs text-muted-foreground truncate">{tx.location}</span>
                  <div className="flex justify-center items-center text-soc-muted">
                    <DeviceIcon device={tx.deviceType} />
                  </div>
                  <span className={`font-mono text-xs font-bold ${getRiskColor(tx.riskScore)}`}>
                    {(tx.riskScore * 100).toFixed(1)}%
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold uppercase w-fit ${getStatusStyle(tx.status)}`}>
                    {getStatusLabel(tx.status)}
                  </span>
                  <div className="space-y-1">
                    <span className="font-mono text-[10px] text-soc-muted block">{formatDate(tx.timestamp)}</span>
                    <div className="flex flex-wrap gap-0.5">
                      {tags.slice(0, 2).map((tag) => (
                        <Badge
                          key={tag}
                          variant="outline"
                          className={`text-[9px] font-mono border px-1 py-0 h-4 ${tagColorClass(tag)}`}
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Select
                      onValueChange={(v) => handleOverride(tx, v as TransactionStatus)}
                      disabled={overridingId === tx.id.toString()}
                    >
                      <SelectTrigger className="h-6 text-[10px] bg-secondary border-soc-border text-foreground w-[88px] px-2">
                        <SelectValue placeholder="Override" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-soc-border">
                        <SelectItem value={TransactionStatus.clean} className="text-xs text-foreground">Clean</SelectItem>
                        <SelectItem value={TransactionStatus.suspicious} className="text-xs text-foreground">Suspicious</SelectItem>
                        <SelectItem value={TransactionStatus.blocked} className="text-xs text-foreground">Blocked</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 text-red-400 hover:bg-red-950/50"
                      title={`Block ${tx.userId}`}
                      disabled={blockingId === tx.userId}
                      onClick={() => handleBlock(tx.userId)}
                    >
                      <UserX className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              );
            })
          )}
        </ScrollArea>
      </div>

      <TransactionDetailModal
        transaction={selectedTx}
        onClose={() => setSelectedTx(null)}
        onOverrideStatus={onOverrideStatus}
        onSubmitFeedback={async (txId, feedback) => {
          const actor = await createActorWithConfig();
          await actor.submitFeedback(txId, feedback as FeedbackType);
        }}
      />
    </div>
  );
}
