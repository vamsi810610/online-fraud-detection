import { Transaction, FeedbackType } from "../backend.d";
import { getStatusStyle, getStatusLabel, getRiskColor, formatTimestamp } from "../utils/fraud";
import { Monitor, Smartphone, Tablet, ThumbsUp, ThumbsDown } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TransactionRowProps {
  tx: Transaction;
  onClick: () => void;
  onFeedback: (txId: bigint, feedback: FeedbackType) => Promise<void>;
  index: number;
}

const DeviceIcon = ({ device }: { device: string }) => {
  const cls = "w-3.5 h-3.5 text-soc-muted";
  if (device === "mobile") return <Smartphone className={cls} />;
  if (device === "tablet") return <Tablet className={cls} />;
  return <Monitor className={cls} />;
};

export default function TransactionRow({ tx, onClick, onFeedback, index }: TransactionRowProps) {
  const riskPct = (tx.riskScore * 100).toFixed(0);

  return (
    <div
      className="group grid grid-cols-[80px_120px_90px_120px_40px_100px_90px_80px_80px] items-center gap-2 px-4 py-2.5 border-b border-soc-border/50 hover:bg-secondary/40 transition-colors duration-100 animate-fade-in-up"
      style={{ animationDelay: `${index * 30}ms` }}
    >
      {/* Clickable area cells */}
      <button
        type="button"
        onClick={onClick}
        className="font-mono text-soc-cyan text-xs truncate text-left hover:underline"
      >
        #{tx.id.toString()}
      </button>

      <button
        type="button"
        onClick={onClick}
        className="font-mono text-xs text-foreground truncate text-left hover:text-soc-cyan transition-colors"
      >
        {tx.userId}
      </button>

      <button
        type="button"
        onClick={onClick}
        className="font-mono text-xs text-foreground font-medium text-right hover:text-soc-cyan transition-colors"
      >
        ${tx.amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </button>

      <button
        type="button"
        onClick={onClick}
        className="text-xs text-muted-foreground truncate text-left"
      >
        {tx.location}
      </button>

      <button
        type="button"
        onClick={onClick}
        className="flex justify-center"
      >
        <DeviceIcon device={tx.deviceType} />
      </button>

      <button
        type="button"
        onClick={onClick}
        className="flex items-center gap-1.5"
      >
        <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${
              tx.riskScore < 0.3 ? "bg-soc-green" :
              tx.riskScore < 0.6 ? "bg-soc-amber" : "bg-soc-red"
            }`}
            style={{ width: `${Math.min(100, tx.riskScore * 100)}%` }}
          />
        </div>
        <span className={`font-mono text-xs tabular-nums ${getRiskColor(tx.riskScore)}`}>
          {riskPct}%
        </span>
      </button>

      <button
        type="button"
        onClick={onClick}
        className="text-left"
      >
        <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold uppercase ${getStatusStyle(tx.status)}`}>
          {getStatusLabel(tx.status)}
        </span>
      </button>

      <button
        type="button"
        onClick={onClick}
        className="font-mono text-[10px] text-soc-muted text-left"
      >
        {formatTimestamp(tx.timestamp)}
      </button>

      {/* Feedback */}
      <div className="flex items-center gap-1">
        <Button
          type="button"
          size="icon"
          variant="ghost"
          className="w-6 h-6 text-emerald-500 hover:bg-emerald-950/50 hover:text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity"
          title="False Positive"
          onClick={(e) => { e.stopPropagation(); void onFeedback(tx.id, FeedbackType.falsePositive); }}
        >
          <ThumbsUp className="w-3 h-3" />
        </Button>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          className="w-6 h-6 text-red-500 hover:bg-red-950/50 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
          title="Confirmed Fraud"
          onClick={(e) => { e.stopPropagation(); void onFeedback(tx.id, FeedbackType.confirmedFraud); }}
        >
          <ThumbsDown className="w-3 h-3" />
        </Button>
      </div>
    </div>
  );
}
