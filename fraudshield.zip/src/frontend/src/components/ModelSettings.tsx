import { useState, useEffect, useCallback } from "react";
import { ModelWeights } from "../backend.d";
import { createActorWithConfig } from "../config";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { FeedbackEntry } from "../App";
import {
  Settings,
  DollarSign,
  Zap,
  Smartphone,
  Clock,
  History,
  Save,
  Loader2,
  ThumbsUp,
  ThumbsDown,
  Info,
} from "lucide-react";

interface ModelSettingsProps {
  feedbackLog: FeedbackEntry[];
}

interface WeightConfig {
  key: keyof ModelWeights;
  label: string;
  description: string;
  icon: React.ElementType;
  color: string;
}

const WEIGHT_CONFIGS: WeightConfig[] = [
  {
    key: "amountWeight",
    label: "Amount Weight",
    description: "How strongly large transaction amounts influence the fraud score. Higher = more sensitive to high-value transactions.",
    icon: DollarSign,
    color: "text-red-400",
  },
  {
    key: "velocityWeight",
    label: "Velocity Weight",
    description: "Penalizes rapid successive transactions from the same user. Higher = stricter on transaction speed patterns.",
    icon: Zap,
    color: "text-amber-400",
  },
  {
    key: "deviceWeight",
    label: "Device Weight",
    description: "Weights mobile device usage as a risk factor. Higher = more suspicious of mobile transactions.",
    icon: Smartphone,
    color: "text-purple-400",
  },
  {
    key: "timeWeight",
    label: "Time-of-Day Weight",
    description: "Penalizes transactions occurring at unusual hours (midnight–5am). Higher = stricter on off-hours activity.",
    icon: Clock,
    color: "text-blue-400",
  },
  {
    key: "historyWeight",
    label: "History Weight",
    description: "Incorporates past flagging history into the risk score. Higher = user past behavior heavily influences scoring.",
    icon: History,
    color: "text-soc-cyan",
  },
];

function formatFeedbackType(type: string) {
  if (type === "confirmedFraud") return { label: "Confirmed Fraud", icon: ThumbsDown, cls: "text-red-400" };
  return { label: "False Positive", icon: ThumbsUp, cls: "text-emerald-400" };
}

export default function ModelSettings({ feedbackLog }: ModelSettingsProps) {
  const [weights, setWeights] = useState<ModelWeights | null>(null);
  const [localWeights, setLocalWeights] = useState<ModelWeights | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const fetchWeights = useCallback(async () => {
    try {
      const actor = await createActorWithConfig();
      const w = await actor.getModelWeights();
      setWeights(w);
      setLocalWeights({ ...w });
    } catch {
      toast.error("Failed to load model weights");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchWeights();
  }, [fetchWeights]);

  const handleWeightChange = (key: keyof ModelWeights, value: number) => {
    setLocalWeights((prev) => prev ? { ...prev, [key]: value } : null);
  };

  const handleSave = async () => {
    if (!localWeights) return;
    setIsSaving(true);
    try {
      const actor = await createActorWithConfig();
      await actor.updateModelWeights(
        localWeights.amountWeight,
        localWeights.velocityWeight,
        localWeights.deviceWeight,
        localWeights.timeWeight,
        localWeights.historyWeight,
      );
      setWeights({ ...localWeights });
      toast.success("Model weights updated successfully");
    } catch {
      toast.error("Failed to save model weights");
    } finally {
      setIsSaving(false);
    }
  };

  const hasChanges = weights && localWeights && (
    weights.amountWeight !== localWeights.amountWeight ||
    weights.velocityWeight !== localWeights.velocityWeight ||
    weights.deviceWeight !== localWeights.deviceWeight ||
    weights.timeWeight !== localWeights.timeWeight ||
    weights.historyWeight !== localWeights.historyWeight
  );

  return (
    <div className="p-6 space-y-6 min-h-full">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground font-display flex items-center gap-2">
            <Settings className="w-6 h-6 text-soc-cyan" />
            Fraud Model Configuration
          </h2>
          <p className="text-sm text-muted-foreground mt-1 font-mono">
            Tune ML scoring weights · Changes apply to future transactions
          </p>
        </div>
        <Button
          type="button"
          onClick={handleSave}
          disabled={isSaving || !hasChanges}
          className={`${hasChanges ? "bg-soc-cyan text-soc-navy shadow-glow-cyan" : "bg-secondary text-muted-foreground"} font-semibold hover:bg-soc-cyan/90 transition-all`}
        >
          {isSaving ? (
            <Loader2 className="w-4 h-4 animate-spin mr-2" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          {isSaving ? "Saving..." : "Save Weights"}
        </Button>
      </div>

      <div className="grid grid-cols-5 gap-4">
        {/* Weight sliders */}
        <div className="col-span-3 space-y-3">
          {WEIGHT_CONFIGS.map((config) => {
            const Icon = config.icon;
            const value = localWeights?.[config.key] ?? 0;

            return (
              <div key={config.key} className="bg-card border border-soc-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Icon className={`w-4 h-4 ${config.color}`} />
                    <span className="text-sm font-medium text-foreground">{config.label}</span>
                  </div>
                  {isLoading ? (
                    <Skeleton className="h-5 w-12 bg-secondary animate-shimmer" />
                  ) : (
                    <span className={`font-mono text-sm font-bold ${config.color}`}>
                      {value.toFixed(2)}
                    </span>
                  )}
                </div>

                {isLoading ? (
                  <Skeleton className="h-2 w-full bg-secondary animate-shimmer" />
                ) : (
                  <Slider
                    value={[value]}
                    onValueChange={([v]) => handleWeightChange(config.key, v)}
                    min={0}
                    max={1}
                    step={0.05}
                    className="w-full"
                  />
                )}

                <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
                  {config.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Right panel: info + feedback log */}
        <div className="col-span-2 space-y-4">
          {/* Info card */}
          <div className="bg-card border border-soc-border rounded-lg p-4">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-4 h-4 text-soc-cyan" />
              <h3 className="text-sm font-semibold text-foreground">How It Works</h3>
            </div>
            <div className="space-y-2 text-xs text-muted-foreground leading-relaxed">
              <p>
                The fraud model computes a <span className="text-foreground font-mono">riskScore</span> for each transaction by combining weighted signals:
              </p>
              <ul className="space-y-1.5 mt-2">
                <li className="flex items-start gap-2">
                  <span className="text-soc-cyan mt-0.5">›</span>
                  <span>Higher weights make the model more sensitive to that particular factor</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-soc-cyan mt-0.5">›</span>
                  <span>All weights are normalized, so relative values matter more than absolute ones</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-soc-cyan mt-0.5">›</span>
                  <span>Feedback (confirm fraud / false positive) trains future model iterations</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Feedback log */}
          <div className="bg-card border border-soc-border rounded-lg overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-soc-border">
              <h3 className="text-sm font-semibold text-foreground">Feedback Log</h3>
              <span className="text-[10px] font-mono text-muted-foreground">{feedbackLog.length} entries</span>
            </div>

            <ScrollArea className="h-[320px]">
              {feedbackLog.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
                  <History className="w-6 h-6 mb-2 opacity-30" />
                  <p className="text-xs font-mono">No feedback submitted yet</p>
                </div>
              ) : (
                <div className="divide-y divide-soc-border/30">
                  {feedbackLog.map((entry, i) => {
                    const fb = formatFeedbackType(entry.feedback);
                    const FbIcon = fb.icon;
                    return (
                      <div key={`${entry.txId}-${i}`} className="px-4 py-2.5 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FbIcon className={`w-3.5 h-3.5 ${fb.cls}`} />
                          <div>
                            <span className="font-mono text-xs text-foreground">TX#{entry.txId}</span>
                            <p className={`text-[10px] font-mono ${fb.cls}`}>{fb.label}</p>
                          </div>
                        </div>
                        <span className="font-mono text-[10px] text-muted-foreground">
                          {entry.timestamp.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </div>
        </div>
      </div>

      <footer className="text-center text-xs text-soc-muted font-mono pt-2">
        © 2026. Built with ♥ using{" "}
        <a href="https://caffeine.ai" target="_blank" rel="noreferrer" className="text-soc-cyan hover:underline">
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
