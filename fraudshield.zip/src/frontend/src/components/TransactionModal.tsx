import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DeviceType } from "../backend.d";
import { Loader2, Send } from "lucide-react";

interface TransactionModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (userId: string, amount: number, location: string, device: DeviceType) => Promise<bigint>;
}

export default function TransactionModal({ open, onClose, onSubmit }: TransactionModalProps) {
  const [userId, setUserId] = useState("");
  const [amount, setAmount] = useState("");
  const [location, setLocation] = useState("");
  const [device, setDevice] = useState<DeviceType>(DeviceType.desktop);
  const [isPending, setIsPending] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId || !amount || !location) return;
    setIsPending(true);
    try {
      await onSubmit(userId.trim(), parseFloat(amount), location.trim(), device);
      setUserId("");
      setAmount("");
      setLocation("");
      setDevice(DeviceType.desktop);
      onClose();
    } catch {
      // error handled by parent
    } finally {
      setIsPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-soc-panel border-soc-border text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="text-foreground font-display flex items-center gap-2">
            <Send className="w-4 h-4 text-soc-cyan" />
            Submit Transaction
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label className="text-sm text-muted-foreground">User ID</Label>
            <Input
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              placeholder="e.g. user_alice"
              className="bg-secondary border-soc-border text-foreground font-mono placeholder:text-muted-foreground/50"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-sm text-muted-foreground">Amount (USD)</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="250.00"
              className="bg-secondary border-soc-border text-foreground font-mono placeholder:text-muted-foreground/50"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-sm text-muted-foreground">Location</Label>
            <Input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. New York, US"
              className="bg-secondary border-soc-border text-foreground placeholder:text-muted-foreground/50"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-sm text-muted-foreground">Device Type</Label>
            <Select value={device} onValueChange={(v) => setDevice(v as DeviceType)}>
              <SelectTrigger className="bg-secondary border-soc-border text-foreground">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border-soc-border">
                <SelectItem value={DeviceType.desktop} className="text-foreground">Desktop</SelectItem>
                <SelectItem value={DeviceType.tablet} className="text-foreground">Tablet</SelectItem>
                <SelectItem value={DeviceType.mobile} className="text-foreground">Mobile</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="mt-6">
            <Button type="button" variant="ghost" onClick={onClose} disabled={isPending}
              className="text-muted-foreground hover:text-foreground">
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isPending}
              className="bg-soc-cyan text-soc-navy font-semibold hover:bg-soc-cyan/90"
            >
              {isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {isPending ? "Submitting..." : "Submit Transaction"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
