import { useState, useMemo } from "react";
import { Transaction, TransactionStatus, FeedbackType, DeviceType } from "../backend.d";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import TransactionRow from "./TransactionRow";
import TransactionModal from "./TransactionModal";
import TransactionDetailModal from "./TransactionDetailModal";
import {
  Activity,
  AlertTriangle,
  ShieldX,
  TrendingUp,
  Plus,
  Play,
  RefreshCw,
} from "lucide-react";

interface DashboardProps {
  transactions: Transaction[];
  isLoading: boolean;
  onSubmitFeedback: (txId: bigint, feedback: FeedbackType) => Promise<void>;
  onOverrideStatus: (txId: bigint, newStatus: TransactionStatus) => Promise<void>;
  onSubmitTransaction: (userId: string, amount: number, location: string, device: DeviceType) => Promise<bigint>;
  onRunSimulation: () => Promise<void>;
  onRefresh: () => Promise<void>;
}

interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ElementType;
  color: string;
  isLoading: boolean;
}

function StatCard({ label, value, icon: Icon, color, isLoading }: StatCardProps) {
  return (
    <div className={`bg-card border border-soc-border rounded-lg p-4 flex items-start gap-4 relative overflow-hidden`}>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider mb-1">{label}</p>
        {isLoading ? (
          <Skeleton className="h-7 w-16 bg-secondary animate-shimmer" />
        ) : (
          <p className="text-2xl font-bold font-display text-foreground">{value}</p>
        )}
      </div>
    </div>
  );
}

export default function Dashboard({
  transactions,
  isLoading,
  onSubmitFeedback,
  onOverrideStatus,
  onSubmitTransaction,
  onRunSimulation,
  onRefresh,
}: DashboardProps) {
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const stats = useMemo(() => {
    const total = transactions.length;
    const suspicious = transactions.filter((t) => t.status === TransactionStatus.suspicious).length;
    const blocked = transactions.filter((t) => t.status === TransactionStatus.blocked).length;
    const fraudRate = total > 0 ? (((suspicious + blocked) / total) * 100).toFixed(1) : "0.0";
    return { total, suspicious, blocked, fraudRate };
  }, [transactions]);

  const recentTransactions = useMemo(() => {
    return [...transactions]
      .sort((a, b) => Number(b.timestamp) - Number(a.timestamp))
      .slice(0, 10);
  }, [transactions]);

  const handleSimulation = async () => {
    setIsSimulating(true);
    try {
      await onRunSimulation();
    } finally {
      setIsSimulating(false);
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setIsRefreshing(false);
    }
  };

  return (
    <div className="p-6 space-y-6 min-h-full">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground font-display flex items-center gap-2">
            <Activity className="w-6 h-6 text-soc-cyan" />
            Real-Time Monitoring
          </h2>
          <p className="text-sm text-muted-foreground mt-1 font-mono">
            Live transaction feed · Auto-refresh every 10s
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="border-soc-border text-muted-foreground hover:text-foreground hover:bg-secondary"
          >
            <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleSimulation}
            disabled={isSimulating}
            className="border-soc-cyan/40 text-soc-cyan hover:bg-soc-cyan/10"
          >
            <Play className={`w-3.5 h-3.5 mr-1.5 ${isSimulating ? "animate-pulse" : ""}`} />
            {isSimulating ? "Running..." : "Run Simulation"}
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={() => setShowSubmitModal(true)}
            className="bg-soc-cyan text-soc-navy font-semibold hover:bg-soc-cyan/90"
          >
            <Plus className="w-3.5 h-3.5 mr-1.5" />
            Submit Transaction
          </Button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard
          label="Total Transactions"
          value={stats.total}
          icon={Activity}
          color="bg-soc-cyan/15 text-soc-cyan"
          isLoading={isLoading}
        />
        <StatCard
          label="Suspicious"
          value={stats.suspicious}
          icon={AlertTriangle}
          color="bg-amber-950/60 text-amber-400"
          isLoading={isLoading}
        />
        <StatCard
          label="Blocked"
          value={stats.blocked}
          icon={ShieldX}
          color="bg-red-950/60 text-red-400"
          isLoading={isLoading}
        />
        <StatCard
          label="Fraud Rate"
          value={`${stats.fraudRate}%`}
          icon={TrendingUp}
          color="bg-purple-950/60 text-purple-400"
          isLoading={isLoading}
        />
      </div>

      {/* Live Transaction Feed */}
      <div className="bg-card border border-soc-border rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-soc-border">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-soc-green animate-pulse" />
            <h3 className="text-sm font-semibold text-foreground font-display">Live Transaction Feed</h3>
            <span className="text-[10px] font-mono text-soc-muted ml-2">Last 10 transactions</span>
          </div>
          <span className="text-[10px] font-mono text-soc-muted">
            {transactions.length} total
          </span>
        </div>

        {/* Table header */}
        <div className="grid grid-cols-[80px_120px_90px_120px_40px_100px_90px_80px_80px] gap-2 px-4 py-2 border-b border-soc-border/50 bg-secondary/30">
          {["TX ID", "User ID", "Amount", "Location", "Dev", "Risk Score", "Status", "Time", ""].map((h) => (
            <span key={h} className="text-[10px] font-mono uppercase tracking-widest text-soc-muted">
              {h}
            </span>
          ))}
        </div>

        <ScrollArea className="h-[360px]">
          {isLoading ? (
            <div className="space-y-0">
              {["sk1","sk2","sk3","sk4","sk5","sk6"].map((sk) => (
                <div
                  key={sk}
                  className="grid grid-cols-[80px_120px_90px_120px_40px_100px_90px_80px_80px] gap-2 px-4 py-3 border-b border-soc-border/30"
                >
                  {["a","b","c","d","e","f","g","h"].map((s) => (
                    <Skeleton key={s} className="h-3 bg-secondary animate-shimmer" />
                  ))}
                </div>
              ))}
            </div>
          ) : recentTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
              <Activity className="w-8 h-8 mb-3 opacity-30" />
              <p className="text-sm font-mono">No transactions yet</p>
              <p className="text-xs mt-1 opacity-60">Submit a transaction or run a simulation</p>
            </div>
          ) : (
            recentTransactions.map((tx, i) => (
              <TransactionRow
                key={tx.id.toString()}
                tx={tx}
                index={i}
                onClick={() => setSelectedTx(tx)}
                onFeedback={onSubmitFeedback}
              />
            ))
          )}
        </ScrollArea>
      </div>

      {/* Footer */}
      <footer className="text-center text-xs text-soc-muted font-mono pt-2">
        © 2026. Built with ♥ using{" "}
        <a href="https://caffeine.ai" target="_blank" rel="noreferrer" className="text-soc-cyan hover:underline">
          caffeine.ai
        </a>
      </footer>

      {/* Modals */}
      <TransactionModal
        open={showSubmitModal}
        onClose={() => setShowSubmitModal(false)}
        onSubmit={onSubmitTransaction}
      />
      <TransactionDetailModal
        transaction={selectedTx}
        onClose={() => setSelectedTx(null)}
        onOverrideStatus={onOverrideStatus}
        onSubmitFeedback={onSubmitFeedback}
      />
    </div>
  );
}
