import { ShieldAlert, LayoutDashboard, AlertTriangle, Users, Settings, Activity } from "lucide-react";
import { View } from "../App";

interface SidebarProps {
  activeView: View;
  onNavigate: (view: View) => void;
}

const navItems: { id: View; label: string; icon: React.ElementType; badge?: string }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "alerts", label: "Fraud Alerts", icon: AlertTriangle },
  { id: "profiles", label: "User Profiles", icon: Users },
  { id: "model", label: "Model Config", icon: Settings },
];

export default function Sidebar({ activeView, onNavigate }: SidebarProps) {
  return (
      <aside className="w-64 shrink-0 flex flex-col bg-sidebar border-r border-soc-border relative z-20">
      {/* Logo */}
      <div className="p-6 border-b border-soc-border">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-soc-cyan/15 border border-soc-cyan/40 flex items-center justify-center shadow-glow-cyan">
            <ShieldAlert className="w-5 h-5 text-soc-cyan" />
          </div>
          <div>
            <h1 className="text-base font-bold text-foreground tracking-tight font-display">
              FraudShield
            </h1>
            <p className="text-[10px] text-soc-muted font-mono uppercase tracking-widest">
              ML Detection
            </p>
          </div>
        </div>
      </div>

      {/* Live indicator */}
      <div className="px-4 py-3 border-b border-soc-border">
        <div className="flex items-center gap-2 text-xs text-soc-muted">
          <div className="relative flex items-center justify-center w-4 h-4">
            <span className="absolute inline-flex h-2 w-2 rounded-full bg-soc-green animate-ping opacity-75" />
            <span className="inline-flex h-2 w-2 rounded-full bg-soc-green" />
          </div>
          <span className="font-mono uppercase tracking-wider text-[10px] text-soc-green">
            System Online
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-3">
        <p className="text-[9px] font-mono uppercase tracking-widest text-soc-muted px-3 mb-3">
          Operations
        </p>
        <ul className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => onNavigate(item.id)}
                  className={`
                    w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150
                    ${isActive
                      ? "bg-soc-cyan/15 text-soc-cyan border border-soc-cyan/30 shadow-glow-cyan"
                      : "text-sidebar-foreground hover:bg-secondary/60 hover:text-foreground border border-transparent"
                    }
                  `}
                >
                  <Icon className={`w-4 h-4 ${isActive ? "text-soc-cyan" : "text-soc-muted"}`} />
                  <span className={`font-medium ${isActive ? "text-soc-cyan" : ""}`}>
                    {item.label}
                  </span>
                  {isActive && (
                    <span className="ml-auto w-1.5 h-1.5 rounded-full bg-soc-cyan" />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-soc-border">
        <div className="flex items-center gap-2 text-[10px] text-soc-muted font-mono">
          <Activity className="w-3 h-3" />
          <span>Polling every 10s</span>
        </div>
      </div>
    </aside>
  );
}
