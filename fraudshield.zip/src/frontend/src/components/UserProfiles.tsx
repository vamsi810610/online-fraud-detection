import { useState, useEffect, useCallback, useMemo } from "react";
import { UserProfile } from "../backend.d";
import { createActorWithConfig } from "../config";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  Users,
  Search,
  ShieldOff,
  Shield,
  KeyRound,
  AlertCircle,
  CheckCircle,
} from "lucide-react";

interface UserProfilesProps {
  onBlockUser: (userId: string) => Promise<void>;
  onUnblockUser: (userId: string) => Promise<void>;
}

export default function UserProfiles({ onBlockUser, onUnblockUser }: UserProfilesProps) {
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [actionId, setActionId] = useState<string | null>(null);

  const fetchProfiles = useCallback(async () => {
    try {
      const actor = await createActorWithConfig();
      const data = await actor.getAllUserProfiles();
      setProfiles(data);
    } catch {
      toast.error("Failed to fetch user profiles");
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchProfiles();
  }, [fetchProfiles]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return profiles.filter((p) => p.userId.toLowerCase().includes(q));
  }, [profiles, search]);

  const handleBlock = async (userId: string) => {
    setActionId(userId + "_block");
    try {
      await onBlockUser(userId);
      await fetchProfiles();
    } finally {
      setActionId(null);
    }
  };

  const handleUnblock = async (userId: string) => {
    setActionId(userId + "_unblock");
    try {
      await onUnblockUser(userId);
      await fetchProfiles();
    } finally {
      setActionId(null);
    }
  };

  const handleRecordFailedLogin = async (userId: string) => {
    setActionId(userId + "_login");
    try {
      const actor = await createActorWithConfig();
      const count = await actor.recordFailedLogin(userId);
      toast.warning(`Failed login recorded. Total: ${count.toString()}`);
      await fetchProfiles();
    } catch {
      toast.error("Failed to record login attempt");
    } finally {
      setActionId(null);
    }
  };

  const getRiskBarColor = (level: number) => {
    if (level < 0.3) return "bg-soc-green";
    if (level < 0.6) return "bg-soc-amber";
    return "bg-soc-red";
  };

  const getRiskLabel = (level: number) => {
    if (level < 0.3) return { label: "Low", cls: "text-soc-green" };
    if (level < 0.6) return { label: "Medium", cls: "text-soc-amber" };
    return { label: "High", cls: "text-soc-red" };
  };

  return (
    <div className="p-6 space-y-5 min-h-full">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground font-display flex items-center gap-2">
            <Users className="w-6 h-6 text-soc-cyan" />
            User Profiles
          </h2>
          <p className="text-sm text-muted-foreground mt-1 font-mono">
            {profiles.length} users monitored
          </p>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by user ID..."
            className="pl-9 bg-secondary border-soc-border text-foreground w-64 placeholder:text-muted-foreground/50"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-soc-border rounded-lg overflow-hidden">
        <div className="grid grid-cols-[160px_70px_70px_100px_80px_70px_90px_160px] gap-3 px-4 py-2.5 border-b border-soc-border bg-secondary/30">
          {["User ID", "Total TX", "Flagged", "Avg Spend", "Risk Level", "Failed", "Status", "Actions"].map((h) => (
            <span key={h} className="text-[10px] font-mono uppercase tracking-widest text-soc-muted">
              {h}
            </span>
          ))}
        </div>

        <ScrollArea className="h-[calc(100vh-280px)]">
          {isLoading ? (
            <div className="space-y-0">
              {["s1","s2","s3","s4","s5","s6"].map((sk) => (
                <div key={sk} className="grid grid-cols-[160px_70px_70px_100px_80px_70px_90px_160px] gap-3 px-4 py-4 border-b border-soc-border/30">
                  {["a","b","c","d","e","f","g","h"].map((s) => (
                    <Skeleton key={s} className="h-3 bg-secondary animate-shimmer" />
                  ))}
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
              <Users className="w-8 h-8 mb-3 opacity-30" />
              <p className="text-sm font-mono">No users found</p>
            </div>
          ) : (
            filtered.map((profile) => {
              const risk = getRiskLabel(profile.riskLevel);
              return (
                <div
                  key={profile.userId}
                  className="grid grid-cols-[160px_70px_70px_100px_80px_70px_90px_160px] gap-3 px-4 py-3.5 border-b border-soc-border/30 hover:bg-secondary/30 transition-colors items-center"
                >
                  {/* User ID */}
                  <span className="font-mono text-xs text-foreground truncate">
                    {profile.userId}
                  </span>

                  {/* Total TX */}
                  <span className="font-mono text-xs text-soc-cyan text-center">
                    {profile.totalTransactions.toString()}
                  </span>

                  {/* Flagged */}
                  <span className={`font-mono text-xs text-center ${Number(profile.flaggedCount) > 0 ? "text-amber-400" : "text-muted-foreground"}`}>
                    {profile.flaggedCount.toString()}
                  </span>

                  {/* Avg Spend */}
                  <span className="font-mono text-xs text-foreground">
                    ${profile.avgSpend.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>

                  {/* Risk Level */}
                  <div className="space-y-1">
                    <span className={`font-mono text-[10px] font-semibold ${risk.cls}`}>
                      {risk.label}
                    </span>
                    <div className="h-1 bg-secondary rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${getRiskBarColor(profile.riskLevel)}`}
                        style={{ width: `${Math.min(100, profile.riskLevel * 100)}%` }}
                      />
                    </div>
                  </div>

                  {/* Failed Logins */}
                  <span className={`font-mono text-xs text-center ${Number(profile.failedLoginAttempts) >= 3 ? "text-red-400" : "text-muted-foreground"}`}>
                    {profile.failedLoginAttempts.toString()}
                  </span>

                  {/* Status */}
                  <div className="flex items-center gap-1.5">
                    {profile.blocked ? (
                      <>
                        <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                        <span className="text-[10px] font-mono text-red-400">Blocked</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-3.5 h-3.5 text-soc-green" />
                        <span className="text-[10px] font-mono text-soc-green">Active</span>
                      </>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5">
                    {profile.blocked ? (
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-6 text-[10px] px-2 border-soc-green/40 text-soc-green hover:bg-emerald-950/50"
                        disabled={actionId === profile.userId + "_unblock"}
                        onClick={() => handleUnblock(profile.userId)}
                      >
                        <Shield className="w-3 h-3 mr-1" />
                        Unblock
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-6 text-[10px] px-2 border-red-700/40 text-red-400 hover:bg-red-950/50"
                        disabled={actionId === profile.userId + "_block"}
                        onClick={() => handleBlock(profile.userId)}
                      >
                        <ShieldOff className="w-3 h-3 mr-1" />
                        Block
                      </Button>
                    )}
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-6 text-[10px] px-2 border-amber-700/40 text-amber-400 hover:bg-amber-950/50"
                      disabled={actionId === profile.userId + "_login"}
                      onClick={() => handleRecordFailedLogin(profile.userId)}
                    >
                      <KeyRound className="w-3 h-3 mr-1" />
                      Fail Login
                    </Button>
                  </div>
                </div>
              );
            })
          )}
        </ScrollArea>
      </div>

      <footer className="text-center text-xs text-soc-muted font-mono pt-2">
        © 2026. Built with ♥ using{" "}
        <a href="https://caffeine.ai" target="_blank" rel="noreferrer" className="text-soc-cyan hover:underline">
          caffeine.ai
        </a>
      </footer>
    </div>
  );
}
