import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type Time = bigint;
export interface ModelWeights {
    historyWeight: number;
    amountWeight: number;
    deviceWeight: number;
    velocityWeight: number;
    timeWeight: number;
}
export interface UserProfile {
    avgSpend: number;
    userId: string;
    blocked: boolean;
    failedLoginAttempts: bigint;
    flaggedCount: bigint;
    lastTransactionTime: Time;
    riskLevel: number;
    totalTransactions: bigint;
}
export interface Transaction {
    id: bigint;
    status: TransactionStatus;
    userId: string;
    timestamp: Time;
    deviceType: DeviceType;
    amount: number;
    location: string;
    riskScore: number;
}
export enum DeviceType {
    desktop = "desktop",
    tablet = "tablet",
    mobile = "mobile"
}
export enum FeedbackType {
    confirmedFraud = "confirmedFraud",
    falsePositive = "falsePositive"
}
export enum TransactionStatus {
    blocked = "blocked",
    clean = "clean",
    suspicious = "suspicious"
}
export interface backendInterface {
    adminOverrideTransaction(id: bigint, newStatus: TransactionStatus): Promise<void>;
    blockUser(userId: string): Promise<void>;
    getAllTransactions(): Promise<Array<Transaction>>;
    getAllUserProfiles(): Promise<Array<UserProfile>>;
    getModelWeights(): Promise<ModelWeights>;
    getTransactionById(id: bigint): Promise<Transaction>;
    getTransactionsByStatus(status: TransactionStatus): Promise<Array<Transaction>>;
    getUserProfile(userId: string): Promise<UserProfile>;
    recordFailedLogin(userId: string): Promise<bigint>;
    submitFeedback(transactionId: bigint, feedback: FeedbackType): Promise<void>;
    submitTransaction(userId: string, amount: number, location: string, deviceType: DeviceType): Promise<bigint>;
    unblockUser(userId: string): Promise<void>;
    updateModelWeights(amountWeight: number, velocityWeight: number, deviceWeight: number, timeWeight: number, historyWeight: number): Promise<void>;
}
